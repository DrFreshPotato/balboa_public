The scenes are all under the scenes folder, the main json file to consider is the hw_3_5.json that has my custom scene.

The outputs folder has all the png's of the renders of each scene.

And the src code is all out in the root folder.